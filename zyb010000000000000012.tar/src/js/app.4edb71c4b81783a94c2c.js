webpackJsonp([9],{

/***/ "14FN":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "NHnr":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: external "vendor.vue"
var external__vendor_vue_ = __webpack_require__("lRwf");
var external__vendor_vue__default = /*#__PURE__*/__webpack_require__.n(external__vendor_vue_);

// EXTERNAL MODULE: ./node_modules/mint-ui/lib/mint-ui.common.js
var mint_ui_common = __webpack_require__("Au9i");
var mint_ui_common_default = /*#__PURE__*/__webpack_require__.n(mint_ui_common);

// EXTERNAL MODULE: ./node_modules/mint-ui/lib/style.css
var style = __webpack_require__("d8/S");
var style_default = /*#__PURE__*/__webpack_require__.n(style);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/App.vue
//
//
//
//
//
//
//
//

/* harmony default export */ var App = ({
  name: 'App',
  provide: function provide() {
    return {
      reload: this.reload
    };
  },
  data: function data() {
    return {
      isRouterAlive: true,
      transitionName: 'none',
      isAnim: false
    };
  },

  watch: {},
  methods: {
    reload: function reload() {
      var _this = this;

      this.isRouterAlive = false;
      this.$nextTick(function () {
        _this.isRouterAlive = true;
      });
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-91fbb7b4","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/App.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"app"}},[_c('keep-alive',[_c('router-view')],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var selectortype_template_index_0_src_App = (esExports);
// CONCATENATED MODULE: ./src/App.vue
function injectStyle (ssrContext) {
  __webpack_require__("14FN")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  App,
  selectortype_template_index_0_src_App,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var src_App = (Component.exports);

// EXTERNAL MODULE: external "vendor.Router"
var external__vendor_Router_ = __webpack_require__("pRNm");
var external__vendor_Router__default = /*#__PURE__*/__webpack_require__.n(external__vendor_Router_);

// CONCATENATED MODULE: ./src/router/index.js



var interfaces = function interfaces() {
  return __webpack_require__.e/* import() */(0).then(__webpack_require__.bind(null, "wUh3"));
};
var main = function main() {
  return __webpack_require__.e/* import() */(1).then(__webpack_require__.bind(null, "6UM6"));
};
var router_navigate = function navigate() {
  return __webpack_require__.e/* import() */(5).then(__webpack_require__.bind(null, "/KKu"));
};
var newPage = function newPage() {
  return __webpack_require__.e/* import() */(7).then(__webpack_require__.bind(null, "03XJ"));
};
var router_confirm = function confirm() {
  return __webpack_require__.e/* import() */(4).then(__webpack_require__.bind(null, "kqQT"));
};
var loading = function loading() {
  return __webpack_require__.e/* import() */(6).then(__webpack_require__.bind(null, "iC1v"));
};
var router_alert = function alert() {
  return __webpack_require__.e/* import() */(3).then(__webpack_require__.bind(null, "pe/E"));
};
var router_prompt = function prompt() {
  return __webpack_require__.e/* import() */(2).then(__webpack_require__.bind(null, "NIkm"));
};
var toast = function toast() {
  return __webpack_require__.e/* import() */(8).then(__webpack_require__.bind(null, "IhfE"));
};

external__vendor_vue__default.a.use(external__vendor_Router__default.a);

/* harmony default export */ var router = (new external__vendor_Router__default.a({
  routes: [{
    path: '/interfaces',
    name: 'interfaces',
    component: interfaces
  }, {
    path: '/main',
    name: 'main',
    component: main
  }, {
    path: '/navigate',
    name: 'navigate',
    component: router_navigate
  }, {
    path: '/newPage',
    name: 'newPage',
    component: newPage
  }, {
    path: '/confirm',
    name: 'confirm',
    component: router_confirm
  }, {
    path: '/loading',
    name: 'loading',
    component: loading
  }, {
    path: '/toast',
    name: 'toast',
    component: toast
  }, {
    path: '/prompt',
    name: 'prompt',
    component: router_prompt
  }, {
    path: '/alert',
    name: 'alert',
    component: router_alert
  }]
}));
// CONCATENATED MODULE: ./src/tools/routerBridge.js

// const isApp = window.navigator.userAgent.indexOf('pmbs') > 0
var isApp = window.zyb;
if (!isApp) {
  window.zyb = {};
  window.Page = function () {};
  window.zyb.navigateTo = function (param) {
    router.push(param);
  };
  window.zyb.redirectTo = function (param) {
    router.replace(param);
  };
  window.zyb.switchTab = window.zyb.reLaunch = function (param) {
    router.replace(param);
  };
  window.zyb.navigateBack = function (param) {
    router.go(-1);
  };
} else {
  window.router = router;
}
// CONCATENATED MODULE: ./src/main.js
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.







external__vendor_vue__default.a.use(mint_ui_common_default.a);

external__vendor_vue__default.a.config.productionTip = false;

/* eslint-disable no-new */
new external__vendor_vue__default.a({
  el: '#app',
  router: router,
  components: { App: src_App },
  template: '<App/>'
});
// router.push({name: 'main', meta: {back: true}})

/***/ }),

/***/ "d8/S":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "lRwf":
/***/ (function(module, exports) {

module.exports = vendor.vue;

/***/ }),

/***/ "pRNm":
/***/ (function(module, exports) {

module.exports = vendor.Router;

/***/ })

},["NHnr"]);