webpackJsonp([4],{

/***/ "bwRP":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "kqQT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/mint-ui/lib/mint-ui.common.js
var mint_ui_common = __webpack_require__("Au9i");
var mint_ui_common_default = /*#__PURE__*/__webpack_require__.n(mint_ui_common);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/page/interaction/confirm.vue
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var interaction_confirm = ({
  name: 'components',
  data: function data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },

  component: {
    mtButton: mint_ui_common["Button"]
  },
  created: function created() {},
  activated: function activated() {
    window.Page(this);
  },

  methods: {
    showConfirm: function showConfirm() {
      window.zyb.confirm({
        title: '温馨提示',
        content: '您是否想查询快递单号：1234567890',
        confirmButtonText: '马上查询',
        cancelButtonText: '暂不需要',
        success: function success(result) {
          window.zyb.alert({
            title: '' + result.confirm
          });
        }
      });
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-49c47bec","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/page/interaction/confirm.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"scroller-box"},[_c('div',{staticClass:"title"},[_vm._v("确认框Api")]),_vm._v(" "),_c('div',{staticClass:"outer"},[_c('div',[_vm._v("confirm")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"primary","size":"large"},on:{"click":_vm.showConfirm}},[_vm._v("确认框")])],1)])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_interaction_confirm = (esExports);
// CONCATENATED MODULE: ./src/page/interaction/confirm.vue
function injectStyle (ssrContext) {
  __webpack_require__("bwRP")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-49c47bec"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  interaction_confirm,
  page_interaction_confirm,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var src_page_interaction_confirm = __webpack_exports__["default"] = (Component.exports);


/***/ })

});