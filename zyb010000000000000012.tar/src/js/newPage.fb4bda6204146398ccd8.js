webpackJsonp([7],{

/***/ "03XJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/page/navigate/newPage.vue
//
//
//
//
//
//

/* harmony default export */ var newPage = ({
  name: 'components',
  data: function data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },
  created: function created() {},
  activated: function activated() {
    window.Page(this);
  },

  methods: {}
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-230bc269","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/page/navigate/newPage.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"newpage"},[_vm._v("\n  我是新页面\n")])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var navigate_newPage = (esExports);
// CONCATENATED MODULE: ./src/page/navigate/newPage.vue
function injectStyle (ssrContext) {
  __webpack_require__("ojIG")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-230bc269"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  newPage,
  navigate_newPage,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var page_navigate_newPage = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "ojIG":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })

});