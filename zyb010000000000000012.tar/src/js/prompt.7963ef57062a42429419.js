webpackJsonp([2],{

/***/ "FeBl":
/***/ (function(module, exports) {

var core = module.exports = { version: '2.6.9' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),

/***/ "JdRw":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "NIkm":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/json/stringify.js
var stringify = __webpack_require__("mvHQ");
var stringify_default = /*#__PURE__*/__webpack_require__.n(stringify);

// EXTERNAL MODULE: ./node_modules/mint-ui/lib/mint-ui.common.js
var mint_ui_common = __webpack_require__("Au9i");
var mint_ui_common_default = /*#__PURE__*/__webpack_require__.n(mint_ui_common);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/page/interaction/prompt.vue

//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var interaction_prompt = ({
  name: 'components',
  data: function data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },

  component: {
    mtButton: mint_ui_common["Button"]
  },
  created: function created() {},
  activated: function activated() {
    window.Page(this);
  },

  methods: {
    prompt: function prompt() {
      window.zyb.prompt({
        title: '标题单行',
        message: '说明当前状态、提示用户解决方案，最好不要超过两行。',
        placeholder: '给朋友留言',
        okButtonText: '确定',
        cancelButtonText: '取消',
        success: function success(result) {
          window.zyb.alert({
            title: stringify_default()(result)
          });
        }
      });
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-2162a64c","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/page/interaction/prompt.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"scroller-box"},[_c('div',{staticClass:"title"},[_vm._v("对话框Api")]),_vm._v(" "),_c('div',{staticClass:"outer"},[_c('div',[_vm._v("prompt")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"primary","size":"large"},on:{"click":_vm.prompt}},[_vm._v("对话框")])],1)])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_interaction_prompt = (esExports);
// CONCATENATED MODULE: ./src/page/interaction/prompt.vue
function injectStyle (ssrContext) {
  __webpack_require__("JdRw")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-2162a64c"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  interaction_prompt,
  page_interaction_prompt,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var src_page_interaction_prompt = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "mvHQ":
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__("qkKv"), __esModule: true };

/***/ }),

/***/ "qkKv":
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__("FeBl");
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ })

});