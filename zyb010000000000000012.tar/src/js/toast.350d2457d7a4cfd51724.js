webpackJsonp([8],{

/***/ "GESL":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "IhfE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/mint-ui/lib/mint-ui.common.js
var mint_ui_common = __webpack_require__("Au9i");
var mint_ui_common_default = /*#__PURE__*/__webpack_require__.n(mint_ui_common);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/page/interaction/toast.vue
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var toast = ({
  name: 'components',
  data: function data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },

  component: {
    mtButton: mint_ui_common["Button"]
  },
  created: function created() {},
  activated: function activated() {
    window.Page(this);
  },

  methods: {
    toast: function toast() {
      window.zyb.showToast({
        type: 'success',
        content: '操作成功',
        duration: 3000,
        success: function success() {
          window.zyb.alert({
            title: 'toast 消失了'
          });
        }
      });
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-000dbe52","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/page/interaction/toast.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"scroller-box"},[_c('div',{staticClass:"title"},[_vm._v("弱提示Api")]),_vm._v(" "),_c('div',{staticClass:"outer"},[_c('div',[_vm._v("showToast")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"primary","size":"large"},on:{"click":_vm.toast}},[_vm._v("弱提示")])],1)])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var interaction_toast = (esExports);
// CONCATENATED MODULE: ./src/page/interaction/toast.vue
function injectStyle (ssrContext) {
  __webpack_require__("GESL")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-000dbe52"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  toast,
  interaction_toast,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var page_interaction_toast = __webpack_exports__["default"] = (Component.exports);


/***/ })

});