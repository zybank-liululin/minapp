webpackJsonp([5],{

/***/ "/KKu":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/mint-ui/lib/mint-ui.common.js
var mint_ui_common = __webpack_require__("Au9i");
var mint_ui_common_default = /*#__PURE__*/__webpack_require__.n(mint_ui_common);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/page/navigate/navigate.vue
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var navigate_navigate = ({
  name: 'components',
  data: function data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },

  component: {
    mtButton: mint_ui_common["Button"]
  },
  created: function created() {},
  activated: function activated() {
    window.Page(this);
  },

  methods: {
    navigateTo: function navigateTo() {
      window.zyb.navigateTo({ name: 'newPage' });
    },
    redirectTo: function redirectTo() {
      window.zyb.redirectTo({ name: 'newPage' });
    },
    switchTab: function switchTab() {
      window.zyb.switchTab({ name: 'interfaces' });
    },
    navigateBack: function navigateBack() {
      window.zyb.navigateBack();
    },
    reLaunch: function reLaunch() {
      window.zyb.reLaunch({ name: 'main' });
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-371a178f","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/page/navigate/navigate.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"scroller-box"},[_c('div',{staticClass:"title"},[_vm._v("导航栏")]),_vm._v(" "),_c('mt-button',{attrs:{"type":"default","size":"large"},on:{"click":_vm.navigateTo}},[_vm._v("跳转到新页面")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"default","size":"large"},on:{"click":_vm.redirectTo}},[_vm._v("在当前页打开")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"default","size":"large"},on:{"click":_vm.switchTab}},[_vm._v("跳转到另一个Tab组件")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"default","size":"large"},on:{"click":_vm.reLaunch}},[_vm._v("reLaunch")]),_vm._v(" "),_c('mt-button',{staticClass:"item",attrs:{"type":"default","size":"large"},on:{"click":_vm.navigateBack}},[_vm._v("navigateBack")])],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_navigate_navigate = (esExports);
// CONCATENATED MODULE: ./src/page/navigate/navigate.vue
function injectStyle (ssrContext) {
  __webpack_require__("PMNl")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-371a178f"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  navigate_navigate,
  page_navigate_navigate,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var src_page_navigate_navigate = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "PMNl":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })

});